import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-rendez-vous',
  templateUrl: 'rendezVous.html'
})
export class RendezVousPage {
  constructor(public navCtrl: NavController) {
  }

}
