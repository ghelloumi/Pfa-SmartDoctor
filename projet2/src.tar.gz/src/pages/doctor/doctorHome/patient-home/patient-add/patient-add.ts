import { Component } from '@angular/core';
import {NavController, NavParams, ViewController} from 'ionic-angular';

/*
  Generated class for the PatientAdd page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-patient-add',
  templateUrl: 'patient-add.html'
})
export class PatientAddPage {


  nom: any;
  prenom: any;
  age: any;
  maladie: any;

  constructor(public viewCtrl: ViewController) {

  }

  save(): void {

    let patient = {
      nom: this.nom,
      prenom: this.prenom,
      age: this.age,
      maladie: this.maladie
    };

    this.viewCtrl.dismiss(patient);

  }

  close(): void {
    this.viewCtrl.dismiss();
  }

}
